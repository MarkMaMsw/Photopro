#image file in URL
image_file_url = "/image/file/"
#image upload dir, image upload by contributor will be storage in this file
image_upload_dir = 'upload/'
#IP address to access this system
ip_address = "http://127.0.0.1:5000"
#database connection address
database_address = "mongodb+srv://COMP9900_group:comp9900@cluster0.okzv2.mongodb.net/<dbname>?retryWrites=true&w=majority"