# 13/10/2020 Modify login and sign up page --Xinshu Wang
# 13/10/2020 Modify Homepage and search result page --Xinshu Wang