// This is the online backend service
// const url = 'http://13.55.8.94:5000';

const url = "http://127.0.0.1:5000";

export default url;