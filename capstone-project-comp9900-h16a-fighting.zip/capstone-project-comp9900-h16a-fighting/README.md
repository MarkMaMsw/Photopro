# COMP9900
# Project: PhotoPro
# COMP9900-H16A-Fighting!

## Team Member
    1. Longcheng Zhao (Scrum master, backend)
    2. Shaowei Ma (frontend)
    3. Xinshu Wang (frontend)
    4. Yanjie Wang (frontend)
    5. Hao Zhong (backend)

## Structure
    /backend: Software backend folder.
    /frontend: Software frontend folder.
    /diarys: Personal diary files.
    .gitignore: set files that their changes are not recorded by git

## Test 
### Online service
    http://13.55.8.94:3000/#/
### Account
    Contributor:
        user: Nash@gmail.com
        password: 1234
    Explorer:
        user: hao1@gmail.com
        password: qazqaz123
    